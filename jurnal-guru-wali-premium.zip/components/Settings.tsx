
import React, { useState } from 'react';
import { ViewMode, TeacherData } from '../types';
import { Database, Copy, Check, Save, ArrowLeft, ExternalLink, HelpCircle, UserCircle } from 'lucide-react';

interface SettingsProps {
  spreadsheetUrl: string;
  onSaveUrl: (url: string) => void;
  setView: (v: ViewMode) => void;
  teacherData: TeacherData;
  onUpdateTeacherData: (data: TeacherData) => void;
}

const Settings: React.FC<SettingsProps> = ({ spreadsheetUrl, onSaveUrl, setView, teacherData, onUpdateTeacherData }) => {
  const [url, setUrl] = useState(spreadsheetUrl);
  const [copied, setCopied] = useState(false);
  const [teacherForm, setTeacherForm] = useState<TeacherData>(teacherData);

  const appsScriptCode = `function doPost(e) {
  var contents = JSON.parse(e.postData.contents);
  var type = contents.target; // "students" or "logs"
  var data = contents.payload;
  
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(type === "students" ? "DataSiswa" : "JurnalBimbingan");
  
  if (!sheet) {
    sheet = ss.insertSheet(type === "students" ? "DataSiswa" : "JurnalBimbingan");
    if (type === "students") {
      sheet.appendRow(["ID", "Nama", "Kelas", "Alamat", "Telepon", "Catatan", "Timestamp"]);
    } else {
      sheet.appendRow(["Tanggal", "Nama Siswa", "Kelas", "Jenis", "Aspek", "Hasil", "Status", "Tindak Lanjut", "Timestamp"]);
    }
  }

  if (type === "students") {
    sheet.appendRow([data.id, data.name, data.className, data.address, data.phone, data.notes, new Date()]);
  } else {
    sheet.appendRow([data.date, data.studentName, data.className, data.type, data.aspect, data.result, data.status, data.followUp, new Date()]);
  }

  return ContentService.createTextOutput(JSON.stringify({result: "success"})).setMimeType(ContentService.MimeType.JSON);
}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(appsScriptCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTeacherSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateTeacherData(teacherForm);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-20">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold font-orbitron bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">
          Pengaturan Aplikasi
        </h2>
        <button onClick={() => setView(ViewMode.HOME)} className="metallic-black px-6 py-3 rounded-xl font-bold border border-slate-700 flex items-center gap-2">
          <ArrowLeft className="w-5 h-5" /> KEMBALI
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Kolom Kiri: Identitas Guru */}
        <div className="lg:col-span-1 glass-card p-8 rounded-[2.5rem] border border-slate-800 space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-3 bg-cyan-500/10 rounded-2xl border border-cyan-500/20 text-cyan-400">
              <UserCircle className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold">Identitas Guru</h3>
          </div>

          <p className="text-sm text-slate-400 leading-relaxed">
            Data ini akan muncul di Dashboard, Kop Laporan, dan file ekspor dokumen.
          </p>

          <form onSubmit={handleTeacherSave} className="space-y-4">
            <div>
              <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1 tracking-widest">Nama Guru</label>
              <input 
                type="text" 
                value={teacherForm.name}
                onChange={(e) => setTeacherForm({...teacherForm, name: e.target.value})}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 focus:ring-2 focus:ring-cyan-500 outline-none text-sm"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1 tracking-widest">NIP</label>
              <input 
                type="text" 
                value={teacherForm.nip}
                onChange={(e) => setTeacherForm({...teacherForm, nip: e.target.value})}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 focus:ring-2 focus:ring-cyan-500 outline-none text-sm"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1 tracking-widest">Nama Sekolah</label>
              <input 
                type="text" 
                value={teacherForm.school}
                onChange={(e) => setTeacherForm({...teacherForm, school: e.target.value})}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 focus:ring-2 focus:ring-cyan-500 outline-none text-sm"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1 tracking-widest">Alamat Sekolah</label>
              <textarea 
                value={teacherForm.schoolAddress}
                onChange={(e) => setTeacherForm({...teacherForm, schoolAddress: e.target.value})}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 focus:ring-2 focus:ring-cyan-500 outline-none text-sm h-16"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1 tracking-widest">Tahun Ajaran</label>
              <input 
                type="text" 
                value={teacherForm.academicYear}
                onChange={(e) => setTeacherForm({...teacherForm, academicYear: e.target.value})}
                placeholder="Contoh: 2025/2026"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 focus:ring-2 focus:ring-cyan-500 outline-none text-sm font-bold text-cyan-400"
              />
            </div>
            <button 
              type="submit"
              className="w-full bg-cyan-600 hover:bg-cyan-500 py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-cyan-500/10"
            >
              <Save className="w-4 h-4" /> SIMPAN IDENTITAS
            </button>
          </form>
        </div>

        {/* Kolom Tengah: Koneksi Spreadsheet */}
        <div className="lg:col-span-1 glass-card p-8 rounded-[2.5rem] border border-slate-800 space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-3 bg-blue-500/10 rounded-2xl border border-blue-500/20 text-blue-400">
              <Database className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold">Koneksi Spreadsheet</h3>
          </div>

          <p className="text-sm text-slate-400 leading-relaxed">
            Hubungkan aplikasi dengan Google Spreadsheet untuk penyimpanan data permanen di Cloud.
          </p>

          <div className="space-y-4">
            <div>
              <label className="text-[10px] font-bold text-slate-500 uppercase block mb-2 tracking-widest">Web App URL</label>
              <input 
                type="text" 
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://script.google.com/macros/s/.../exec"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 focus:ring-2 focus:ring-blue-500 outline-none transition-all text-[10px] font-mono"
              />
            </div>
            <button 
              onClick={() => onSaveUrl(url)}
              className="w-full bg-blue-600 hover:bg-blue-500 py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-500/20"
            >
              <Save className="w-4 h-4" /> SIMPAN KONEKSI
            </button>
          </div>

          <div className="pt-6 border-t border-slate-800 space-y-4">
            <h4 className="flex items-center gap-2 text-xs font-bold text-slate-300">
              <HelpCircle className="w-4 h-4 text-slate-500" /> Cara Menyiapkan:
            </h4>
            <ol className="text-[10px] text-slate-400 space-y-2 list-decimal pl-4 leading-relaxed">
              <li>Buka Google Spreadsheet baru.</li>
              <li>Klik <span className="text-blue-400">Extensions > Apps Script</span>.</li>
              <li>Hapus semua kode, lalu paste kode di sebelah kanan.</li>
              <li>Klik <span className="text-blue-400">Deploy > New Deployment</span>.</li>
              <li>Setel 'Who has access' ke <span className="text-blue-400">Anyone</span>.</li>
            </ol>
          </div>
        </div>

        {/* Kolom Kanan: Kode Apps Script */}
        <div className="lg:col-span-1 glass-card p-8 rounded-[2.5rem] border border-slate-800 bg-slate-900/30 flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-bold font-orbitron text-slate-300">Apps Script Code</h3>
            <button 
              onClick={handleCopy}
              className="flex items-center gap-2 px-3 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-[10px] font-bold transition-all border border-slate-700"
            >
              {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-blue-400" />}
              {copied ? 'COPIED!' : 'COPY KODE'}
            </button>
          </div>
          
          <pre className="flex-1 bg-slate-950 p-4 rounded-xl border border-slate-800 text-[9px] font-mono text-blue-300 overflow-auto custom-scrollbar leading-relaxed">
            {appsScriptCode}
          </pre>
          
          <a 
            href="https://sheets.new" 
            target="_blank" 
            className="mt-6 flex items-center justify-center gap-2 text-[10px] font-bold text-slate-400 hover:text-blue-400 transition-colors py-2 border border-dashed border-slate-700 rounded-xl"
          >
            BUAT SPREADSHEET BARU <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </div>
  );
};

export default Settings;
